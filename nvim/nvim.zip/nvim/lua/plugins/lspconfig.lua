return {
  {
    "neovim/nvim-lspconfig",
    opts = {
      servers = {
        clangd = {
          cmd = { "clangd", "--enable-config" },
          root_dir = function(fname)
            return require("lspconfig.util").root_pattern("compile_commands.json", ".git")(fname)
          end,
          capabilities = (function()
            local ok, cmp = pcall(require, "cmp_nvim_lsp")
            if ok then return cmp.default_capabilities() end
            return vim.lsp.protocol.make_client_capabilities()
          end)(),
        },
        pylsp = {}, -- регистрация, а настройки применим вручную ниже
      },
    },

    config = function(_, opts)
      local lspconfig = require("lspconfig")

      -- стандартная установка серверов
      for server, server_opts in pairs(opts.servers) do
        lspconfig[server].setup(server_opts)
      end

      -- принудительно задаём настройки для pylsp
      lspconfig.pylsp.setup({
        settings = {
          pylsp = {
            configurationSources = { "ruff" },
            plugins = {
              pycodestyle = { enabled = false },
              flake8 = { enabled = false },
              mccabe = { enabled = false },
              pyflakes = { enabled = false },
              pylint = { enabled = false },
              autopep8 = { enabled = false },
              yapf = { enabled = false },
              ruff = {
                enabled = true,
                lineLength = 120,
              },
              black = {
                enabled = true,
                line_length = 120,
              },
            },
          },
        },
      })
    end,
  },
}
