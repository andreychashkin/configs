
-- You can also add or configure plugins by creating files in this `plugins/` folder
-- Here are some examples:

---@type LazySpec
return {

  -- == Examples of Adding Plugins ==
  "zootedb0t/citruszest.nvim",
  "morhetz/gruvbox",
}
